# coding: utf-8

import re
import numpy as np

def get_ingredients(texte):
    pattern = "(\(?((\d+([//,]\d+)?) *((pièces?)|(bottes?)|(pintes?)|(noix)|(gousses?)|(gallons?)|" \
              "(enveloppes?)|(morceaux?)|(tranches?)|(verres?)|(pincée?)|(boîtes?)|(tasses?)|" \
              "((cuillères?|c\.) *à *(soupe|café|thé|\.s|\.c|s\.|c\.))|(lb)|(oz)|([mc]?[lL])|" \
              "([mkK]?[gG]))?)\)? )+(d.)?(.*)"


    prog = re.compile(pattern)
    result = prog.match(texte)

    if result:
        groups = result.groups()
        return "{}   QUANTITE:{}  INGREDIENT:{}\n".format(texte, groups[0], groups[-1])
    else:
        return "{}:   QUANTITE:  INGREDIENT:{}\n".format(texte, texte)

if __name__ == "__main__":
    pred = []
    true_targets = []
    with open("liste_ingredients.txt", "r") as f:
        for ligne in f.readlines():
            pred.append(get_ingredients(ligne[:-1]))
    print pred
    with open("ingredients_solutions.txt", "r") as f:
        for ligne in f.readlines():
            true_targets.append(ligne)
    print true_targets
    print np.array(pred)==np.array(true_targets)
    print "Accuracy: ", np.mean(np.array(pred)==np.array(true_targets))